CHANAKYA - iPad app package

1. Upload everything in this folder (index.html, manifest.webmanifest, sw.js and the icons folder) to a free web host.
   Easiest: Netlify Drop (app.netlify.com/drop). Drag this whole folder onto the page and it gives you a web address.
   GitHub Pages also works.
2. On your iPad, open that address in Safari.
3. Tap Share, then Add to Home Screen, then Add.
4. Open Chanakya from the new icon. It runs full screen and works offline after the first visit.

Notes
- Your data is saved on the iPad only. Use Progress > Backup and restore > Save backup file now and then.
- It does not share data with the version inside Claude, so pick one to use.
- To update the app later, upload the new files to the same place.
